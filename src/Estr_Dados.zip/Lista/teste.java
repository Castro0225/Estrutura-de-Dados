package Lista;

import java.util.Arrays;

public class teste {
    public static void main(String[] args) {
        int num;
        listaContigua lista = new listaContigua(10);
        for (int i = 0; i < 10; i++) {
            num = (int)(Math.random()*30);
        }
            System.out.println(lista);
    }
}

//