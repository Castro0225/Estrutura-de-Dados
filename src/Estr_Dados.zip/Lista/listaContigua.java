package Lista;

public class listaContigua {

    // Integer permite retornar null, int não.
    private Integer[] vetor;
    private int quant;

    // construtor
    public listaContigua(int tam) {
        this.vetor = new Integer[tam];
        this.quant = 0;
    }

    public int size() {
        return quant;
    }

    public boolean isEmpty() {
        return quant == 0;
    }

    public boolean isFull() {
        return quant == this.vetor.length;
    }

    // leitura do Integer
    public Integer get(int posicao) {
        if (posicao < 0 || posicao >= quant) {
            return null;
        }
        return this.vetor[posicao];
    }
    // inserir no inicio

    public boolean addFirst (Integer num) {
        return add (num, 0);
    }


    // inserir no final
    public boolean addLast(Integer num) {
        if (isFull()) {
            aumentarTamanho();
        }

        this.vetor[quant] = num;
        quant++;
        return true;
    }

    // aumentar tamanho do vetor
    private void aumentarTamanho() {
        Integer[] vetorNovo = new Integer[this.vetor.length * 2];

        for (int i = 0; i < quant; i++) {
            vetorNovo[i] = this.vetor[i];
        }

        this.vetor = vetorNovo;
    }

    // inserir em qualquer posição
    public boolean add(Integer num, int posicao) {
        if (posicao < 0 || posicao > quant) {
            return false;
        }

        if (isFull()) {
            aumentarTamanho();
        }

        // desloca para a direita
        for (int i = quant - 1; i >= posicao; i--) {
            this.vetor[i + 1] = this.vetor[i];
        }

        this.vetor[posicao] = num;
        quant++;
        return true;
    }

    // remover por posição
    public Integer remove(int posicao) {
        if (posicao < 0 || posicao >= quant) {
            return null;
        }

        Integer aux = this.vetor[posicao];

        for (int i = posicao + 1; i < quant; i++) {
            vetor[i - 1] = vetor[i];
        }

        quant--;
        this.vetor[quant] = null;
        return aux;
    }

    // remover por número
    public Integer remove(Integer num) {
        for (int i = 0; i < quant; i++) {
            if (vetor[i].equals(num)) {
                return remove(i);
            }
        }
        return null;
    }

    // metodo de busca

    public int search (int num){
        for (int i  = 0; i < quant; i++) {
            if (this.vetor[i] == num) {
                return i;
            }
        }
        return -1;
    }

}